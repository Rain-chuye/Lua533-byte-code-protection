print('V')
