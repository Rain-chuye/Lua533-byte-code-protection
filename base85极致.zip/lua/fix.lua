print('FIX_VERIFIED')
