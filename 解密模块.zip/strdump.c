/*
** $Id: ldump.c,v 2.37 2015/10/08 15:53:49 roberto Exp $
** save precompiled Lua chunks
** See Copyright Notice in lua.h
*/

#define strdump_c
#define LUA_CORE

#include "lprefix.h"

#include <lapi.h>
#include <unistd.h>
#include <stddef.h>
#include <stdlib.h>
#include "lua.h"

#include "lobject.h"
#include "lstate.h"
#include "strdump.h"
#include "lopcodes.h"

typedef struct {
    lua_State *L;
    lua_Writer writer;
    void *data;
    int strip;
    int status;
	Proto *topproto;
} _DumpState;
/*
** All high-level dumps go through DumpVector; you can change it to
** change the endianness of the result
*/
#define _DumpVector(v,n,D)	_DumpBlock(v,(n)*sizeof((v)[0]),D)

#define _DumpLiteral(s,D)	_DumpBlock(s, sizeof(s) - sizeof(char), D)


static void _DumpBlock (const void *b, size_t size, _DumpState *D) {
  if (D->status == 0 && size > 0) {
    lua_unlock(D->L);
    D->status = (*D->writer)(D->L, b, size, D->data);
    lua_lock(D->L);
  }
}


#define _DumpVar(x,D)		_DumpVector(&x,1,D)


static void _DumpByte (int y, _DumpState *D) {
  lu_byte x = (lu_byte)y;
  _DumpVar(x, D);
}


static void _DumpInt (int x, _DumpState *D) {
  _DumpVar(x, D);
}


static void _DumpNumber (lua_Number x, _DumpState *D) {
  _DumpVar(x, D);
}


static void _DumpInteger (lua_Integer x, _DumpState *D) {
  _DumpVar(x, D);
}

static void _DumpString (const TString *s, _DumpState *D) {
  if (s == NULL)
    _DumpByte(0, D);
  else {
    //nirenr mod
    //size_t size = tsslen(s) + 1;  /* include trailing '\0' */
    unsigned int size = tsslen(s) + 1;  /* include trailing '\0' */
    const char *str = getstr(s);
    if (size < 0xFF)
      _DumpByte(cast_int(size), D);
    else {
      _DumpByte(0xFF, D);
      _DumpVar(size, D);
    }
    _DumpVector(str, size - 1, D);  /* no need to save '\0' */
  }
}

static void _DumpCode (const Proto *f, _DumpState *D) {
  _DumpInt(f->sizecode, D);
  _DumpVector(f->code, f->sizecode, D);
}
static void _DumpFunction(const Proto *f, TString *psource, _DumpState *D);

static void _DumpConstants (const Proto *f, _DumpState *D) {
  int i;
  int n = f->sizek;
  _DumpInt(n, D);
  for (i = 0; i < n; i++) {
    const TValue *o = &f->k[i];
    _DumpByte(ttype(o), D);
    switch (ttype(o)) {
      case LUA_TNIL:
        break;
      case LUA_TBOOLEAN:
        _DumpByte(bvalue(o), D);
            break;
      case LUA_TNUMFLT:
        _DumpNumber(fltvalue(o), D);
            break;
      case LUA_TNUMINT:
        _DumpInteger(ivalue(o), D);
            break;
      case LUA_TSHRSTR:
      case LUA_TLNGSTR:
        _DumpString(tsvalue(o), D);
            break;
      default:
        lua_assert(0);
    }
  }
}


static void _DumpProtos (const Proto *f, _DumpState *D) {
  int i;
  int n = f->sizep;
  _DumpInt(n, D);
  for (i = 0; i < n; i++)
    _DumpFunction(f->p[i], f->source, D);
}

static void _DumpUpvalues (const Proto *f, _DumpState *D) {
  int i, n = f->sizeupvalues;
  _DumpInt(n, D);
  for (i = 0; i < n; i++) {
    _DumpByte(f->upvalues[i].instack, D);
    _DumpByte(f->upvalues[i].idx, D);
  }
}
static void _DumpDebug (const Proto *f, _DumpState *D) {
  int i, n;
  n = (D->strip) ? 0 : f->sizelineinfo;
  _DumpInt(n, D);
  _DumpVector(f->lineinfo, n, D);
  n = (D->strip) ? 0 : f->sizelocvars;
  _DumpInt(n, D);
  for (i = 0; i < n; i++) {
    _DumpString(f->locvars[i].varname, D);
    _DumpInt(f->locvars[i].startpc, D);
    _DumpInt(f->locvars[i].endpc, D);
  }
  n = (D->strip) ? 0 : f->sizeupvalues;
  _DumpInt(n, D);
  for (i = 0; i < n; i++)
    _DumpString(f->upvalues[i].name, D);
}


static void _DumpFunction (const Proto *f, TString *psource, _DumpState *D) {
  _DumpString(f->source, D);
  _DumpInt(f->linedefined, D);
  _DumpInt(f->lastlinedefined, D);
  _DumpByte(f->numparams, D);
  _DumpByte(f->is_vararg, D);
  _DumpByte(f->maxstacksize, D);
  _DumpCode(f, D);
  _DumpConstants(f, D);
  _DumpUpvalues(f, D);
  _DumpProtos(f, D);
  _DumpDebug(f, D);
}


static void _DumpHeader (_DumpState *D) {
  _DumpLiteral(LUA_SIGNATURE, D);
  _DumpByte(LUAC_VERSION, D);
  _DumpByte(LUAC_FORMAT, D);
  _DumpLiteral(LUAC_DATA, D);
  _DumpByte(sizeof(int), D);
  //nirenr mod
  //DumpByte(sizeof(size_t), D);
  _DumpByte(sizeof(unsigned int), D);
  _DumpByte(sizeof(Instruction), D);
  _DumpByte(sizeof(lua_Integer), D);
  _DumpByte(sizeof(lua_Number), D);
  _DumpInteger(LUAC_INT, D);
  _DumpNumber(LUAC_NUM, D);
}

static void Nativeprint(lua_State *L, char *say){
    lua_getglobal(L, "activity");
    if(lua_isnil(L, -1)){
        lua_pop(L, 1);
        lua_getglobal(L, "this");
        if(lua_isnil(L, -1)){
            lua_pop(L, 1);
            lua_getglobal(L, "service");
        }
    }
    lua_getfield(L, -1, "sendMsg");
    if(lua_isnil(L, -1)){
        lua_pop(L, 1);
    } else {
        lua_pushstring(L, say);
        lua_pcall(L, 1, 0, 0);
    }
    lua_pop(L, 1);
}



/*
** dump Lua function as precompiled chunk
*/
static int luaU_dumpso(lua_State *L, const Proto *f, lua_Writer w, void *data,
              int strip) {
  _DumpState D;
  D.L = L;
  D.writer = w;
  D.data = data;
  D.strip = strip;
  D.status = 0;
  D.topproto= f;
  _DumpHeader(&D);
  _DumpByte(f->sizeupvalues, &D);
  _DumpFunction(f, NULL, &D);
  return D.status;
}

static Proto *Upvalues_out(lua_State *L, TValue *o){
    int i;
    Proto *f = getproto(o);
  {//Upvalue防导入修复
        if (f->sizeupvalues > 0xff) {
            Upvaldesc cache_upvalues[0xff];
            for (i = 0; i < 0xff; i++) {
                cache_upvalues[i].instack = 1;
                cache_upvalues[i].idx = i;
                cache_upvalues[i].name = NULL;
            }
            int orig_sizeupvalues = f->sizeupvalues;
            int watch_upvalue_count = 0;
            for (i = 0; i < 0xff; i++) {
                int found = 0;
                for (i = 0; i < orig_sizeupvalues; i++) {
                    if (f->upvalues[i].idx == watch_upvalue_count) {
                        cache_upvalues[watch_upvalue_count].idx = i;
                        cache_upvalues[watch_upvalue_count].instack = f->upvalues[i].instack ? 1
                                                                                             : 0;
                        cache_upvalues[watch_upvalue_count].name = f->upvalues[i].name;
                        watch_upvalue_count++;
                        found = 1;
                        break;
                    }
                }
                if (found == 0) {//断档，说明后头是垃圾
                    break;
                }
            }
            if (watch_upvalue_count == 0) {
                f->sizeupvalues = 1;
                f->upvalues = (Upvaldesc *) malloc(sizeof(Upvaldesc) * f->sizeupvalues);
                f->upvalues[0].instack = 1;
                f->upvalues[0].idx = 0;
                f->upvalues[0].name = NULL;
            } else {
                f->sizeupvalues = watch_upvalue_count;
                f->upvalues = (Upvaldesc *) realloc(f->upvalues,
                                                    sizeof(Upvaldesc) * f->sizeupvalues);
                Nativeprint(L, "已修复Upvalue防导入");
                for (i = 0; i < f->sizeupvalues; i++) {
                    f->upvalues[i].instack = cache_upvalues[i].instack;
                    f->upvalues[i].idx = cache_upvalues[i].idx;
                    f->upvalues[i].name = cache_upvalues[i].name;
                }
            }
        }
    }
    return f;
}

int lua_dumpso (lua_State *L, lua_Writer writer, void *data, int strip) {
  int status;
  TValue *o;
  lua_lock(L);
  api_checknelems(L, 1);
  o = L->top - 1;
  if (isLfunction(o))
    status = luaU_dumpso(L, Upvalues_out(L, o), writer, data, strip);
  else
    status = 1;
  lua_unlock(L);
  return status;
}
