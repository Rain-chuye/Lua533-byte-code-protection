#include <lua.h>
#include <lauxlib.h>
#include <lobject.h>
#include <lstate.h>
#include <string.h>
#include <stdlib.h>
#include <lapi.h>
#include <unistd.h>
#include <lopcodes.h>
#include <strdump.h>

int luaopen_LuaCTools(lua_State *L);

static void _luaL_setfuncs(lua_State *L, const luaL_Reg *l, int nup) {
    luaL_checkstack(L, nup + 1, "太多上值(upvalues)");
    for (; l->name != NULL; l++) {
        int i;
        lua_pushstring(L, l->name);
        for (i = 0; i < nup; i++)
            lua_pushvalue(L, -(nup + 1));
        lua_pushcclosure(L, l->func, nup);
        lua_settable(L, -(nup + 3));
    }
    lua_pop(L, nup);
}

static int writer (lua_State *L, const void *b, size_t size, void *B) {
  (void)L;
    luaL_addlstring((luaL_Buffer *) B, (const char *)b, size);
  return 0;
}

static int Native_dump_s (lua_State *L) {
    luaL_Buffer b;
    int strip = lua_toboolean(L, 2);
    luaL_checktype(L, 1, LUA_TFUNCTION);
    lua_settop(L, 1);
    luaL_buffinit(L,&b);
    if (lua_dumpso(L, writer, &b, strip) != 0)
        return luaL_error(L, "unable to dump given function");
    luaL_pushresult(&b);
    return 1;
}

static luaL_Reg LuaCTools_l[] = {
	    {"dump", Native_dump_s},
        {NULL, NULL},
};

int luaopen_LuaCTools(lua_State *L) {
    lua_newtable(L);
    _luaL_setfuncs(L, LuaCTools_l, 0);
    lua_pushliteral(L, "LuaCTools");
    lua_setfield(L, -2, "_NAME");
    lua_pushliteral(L, "1.0.1");
    lua_setfield(L, -2, "_VERSION");
	lua_pushinteger(L, (lua_Integer) L);
	lua_setfield(L, -2, "VM指针");
    lua_pushliteral(L, "LuaCTools：\n"
	                          "利用VM逻辑漏洞越过一些加密，但是无法还原某些修改。。\n");
    lua_setfield(L, -2, "_INFOMATION");
    return 1;
}


